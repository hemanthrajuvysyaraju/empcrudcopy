package models;

import java.util.ArrayList;

public class EmployeeList extends ArrayList<Employee> {

}
